###########################

# This is the script to run for making a warping/astrometric solution to LMIRCam
# See https://dewarp.readthedocs.io for documentation

import numpy as np
from astrom_lmircam_soln import *
from astrom_lmircam_soln import dewarp
from astropy.io import fits


#####################################################################
# SET THE DEWARP COEFFICIENTS

# dewarp coefficients

# N.b. These are valid for 2048x2048 LMIRcam full readouts. If you want to
# dewarp a subarray, you need to pad the images.

# 2019 Jan 25, DX only:
Kx = [[  1.53484821e+00,  1.02242631e-02, -7.62529074e-06,   3.01397583e-10],
        [  1.01609380e+00,  -1.67032792e-05,   8.83706127e-09,  -9.33817389e-14],
        [ -2.30147408e-05,  -1.56357707e-09,   2.07411145e-12,  -8.65727769e-16],
        [  7.13358606e-09,   1.49417672e-12,  -1.61619128e-15,   5.24106088e-19]]
Ky = [[  1.51620772e+01,   9.77986282e-01,  -3.28698979e-06,   6.96761931e-09],
        [ -1.56775963e-02,  -1.41085603e-05,  -4.89279783e-09,   1.75661648e-12],
        [  1.15874971e-05,   5.20977887e-10,   8.83909100e-12,  -2.78133098e-15],
        [ -5.66801592e-10,   2.66518618e-12,  -3.08650185e-15,   9.23903266e-19]]

#####################################################################
# DEWARP TEST FILE

# this is just to get the shape; image content doesn't matter
hdul = fits.open('pinholes_2019A_DX_predewarp.fits')
imagePinholes = hdul[0].data.copy()

# map the coordinates that define the entire image plane
# (transposition due to a coefficient definition change btwn Python and IDL)
print(np.array(Kx).T)
dewarp_coords = dewarp.make_dewarp_coordinates(imagePinholes.shape,
                                               np.array(Kx).T,
                                               np.array(Ky).T)
'''
dewarp_coords = dewarp.make_dewarp_coordinates(imagePinholes.shape,
                                               np.array(Kx).T,
                                               np.array(Ky).T)
'''

## CAN START FOR-LOOP HERE

# grab the pre-dewarp image and header
imageAsterism, header = fits.getdata('pinholes_2019A_DX_predewarp.fits',
                                     0, header=True)

# dewarp the image; use of precomputed coordinates makes this faster
# inside of a for-loop
dewarpedAsterism = dewarp.dewarp_with_precomputed_coords(imageAsterism,
                                                         dewarp_coords,
                                                         order=3)

# write out
fits.writeto('test_post_dewarping.fits',
             np.squeeze(dewarpedAsterism),
             header,
             overwrite=False)

#####################################################################
